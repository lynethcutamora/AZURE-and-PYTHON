SELECT * FROM SalesLT.SalesOrderDetail
WHERE OrderQty >10
ORDER BY UnitPrice;

SELECT * FROM SalesLT.SalesOrderDetail
WHERE OrderQty >10
ORDER BY OrderQty DESC;